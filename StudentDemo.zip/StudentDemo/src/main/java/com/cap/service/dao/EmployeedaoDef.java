package com.cap.service.dao;

import com.cap.service.model.Employee;

public interface EmployeedaoDef {

	public Iterable<Employee> listAllEmployee(Employee employee);

	public Employee getEmployeeById(Employee employee);

	public Employee saveEmployee(Employee employee);

	public Employee deleteEmployee(Employee employee);

}
