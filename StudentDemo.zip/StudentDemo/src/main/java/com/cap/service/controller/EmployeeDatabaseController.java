package com.cap.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cap.service.dao.EmployeedaoDef;
import com.cap.service.model.Employee;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/EmployeeDatabaseController")
@Api(value = "EmployeeDatabaseController", description = "Operations pertaining to DB requests ")
public class EmployeeDatabaseController {

	private EmployeedaoDef employeedaoDef;

	@Autowired
	public void setEmployeedaoDef(EmployeedaoDef employeedaoDef) {
		this.employeedaoDef = employeedaoDef;
	}

	/*
	 * List all records
	 */

	@ApiOperation(value = "View a list of available Records", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@RequestMapping(value = "/listEmployee", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public Iterable<Employee> listEmployee(Model model) {
		Employee employee = new Employee();
		@SuppressWarnings("unchecked")
		Iterable<Employee> EmployeeList = (Iterable<Employee>) employeedaoDef.listAllEmployee(employee);
		return EmployeeList;
	}

	/*
	 * Show record by id
	 */

	@ApiOperation(value = "Search a Record with an ID", response = Employee.class)
	@RequestMapping(value = "/showEmployee/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public Employee showEmployee(@PathVariable String id, Model model) {

		Employee employee = new Employee();
		employee.setEmp_id(Integer.parseInt(id));
		employee = employeedaoDef.getEmployeeById(employee);

		return employee;
	}

	@ApiOperation(value = "Delete a Employee by id")
	@RequestMapping(value = "/deleteEmployee/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity delete(@PathVariable String id) {
		Employee employee = new Employee();
		employee.setEmp_id(Integer.parseInt(id));
		employeedaoDef.deleteEmployee(employee);
		return new ResponseEntity("Employee deleted successfully", HttpStatus.OK);

	}

	@ApiOperation(value = "Save Employee")
	@RequestMapping(value = "/saveEmployee", method = RequestMethod.POST, produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity saveEmployee(@RequestBody Employee employee) {
		employeedaoDef.saveEmployee(employee);
		return new ResponseEntity("Employee saved successfully \n", HttpStatus.OK);
	}

}
