package com.cap.service.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cap.service.dao.service.EmployeeService;
import com.cap.service.model.Employee;

@Component
public class EmployeedaoImpl implements EmployeedaoDef {

	private Logger log = LogManager.getLogger(EmployeedaoImpl.class);

	private EmployeeService employeeService;

	@Autowired
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	@Override
	public Iterable<Employee> listAllEmployee(Employee employee) {
		// TODO Auto-generated method stub
		log.info("calling  listAllStudent........");

		Iterable<Employee> employeeList = employeeService.listAllEmployee();

		return employeeList;
	}

	@Override
	public Employee getEmployeeById(Employee employee) {
		// TODO Auto-generated method stub
		employee = employeeService.getEmployeeById(employee.getEmp_id());
		return employee;
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employee = employeeService.saveEmployee(employee);
		return employee;
	}

	@Override
	public Employee deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub\
		employeeService.deleteEmployee(employee.getEmp_id());
		return employee;
	}

}
