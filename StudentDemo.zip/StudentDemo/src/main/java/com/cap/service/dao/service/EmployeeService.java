package com.cap.service.dao.service;

import com.cap.service.model.Employee;

public interface EmployeeService {

	/* Employee defination */

	Iterable<Employee> listAllEmployee();

	Employee getEmployeeById(Integer id);

	Employee saveEmployee(Employee student);

	void deleteEmployee(Integer id);

	void deleteAllEmployee();
}
