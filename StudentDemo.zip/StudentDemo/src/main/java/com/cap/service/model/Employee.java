package com.cap.service.model;

import java.io.Serializable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "Employee")

@Access(AccessType.FIELD)

public class Employee implements Serializable {

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	@ApiModelProperty(notes = "The database generated product ID")

	@Id
	private Integer emp_id;
	private String emp_NAME;
	private String emp_dob;
	private String emp_mobile;
	private String emp_salary;

	// Getter And Setter
	public Integer getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(Integer emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_NAME() {
		return emp_NAME;
	}

	public void setEmp_NAME(String emp_NAME) {
		this.emp_NAME = emp_NAME;
	}

	public String getEmp_dob() {
		return emp_dob;
	}

	public void setEmp_dob(String emp_dob) {
		this.emp_dob = emp_dob;
	}

	public String getEmp_mobile() {
		return emp_mobile;
	}

	public void setEmp_mobile(String emp_mobile) {
		this.emp_mobile = emp_mobile;
	}

	public String getEmp_salary() {
		return emp_salary;
	}

	public void setEmp_salary(String emp_salary) {
		this.emp_salary = emp_salary;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	// toString
	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_NAME=" + emp_NAME + ", emp_dob=" + emp_dob + ", emp_mobile="
				+ emp_mobile + ", emp_salary=" + emp_salary + "]";
	}

	// Constructor using field
	public Employee(Integer emp_id, String emp_NAME, String emp_dob, String emp_mobile, String emp_salary) {
		super();
		this.emp_id = emp_id;
		this.emp_NAME = emp_NAME;
		this.emp_dob = emp_dob;
		this.emp_mobile = emp_mobile;
		this.emp_salary = emp_salary;
	}

	// Constructor from super class
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

}
